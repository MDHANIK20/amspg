
<div class="span5">
        <div class="control-group">
            <label class="control-label">Room No</label>
            <div class="controls">
              <input type="text" name="rid" value="{{$room->rno}}" readonly >
            </div>
        </div>
</div>
<div class="span5">
        <div class="control-group">
            <label class="control-label">DOJ</label>
            <div class="controls">
              <input type="text" name="doj" value="{{$users->doj}}" readonly >
            </div>
        </div>
</div>
<div class="span5">
        <div class="control-group">
            <label class="control-label">Payable Rent</label>
            <div class="controls">
              <input type="text" name="rent" id="payableAmount" value="{{$payableAmount }}" readonly >
            </div>
        </div>
</div>
    

