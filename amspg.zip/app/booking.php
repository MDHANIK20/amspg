<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class booking extends Model
{
    //
}
