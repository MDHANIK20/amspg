<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userDetails extends Model
{
    //

   

    protected $table="user_details";

    public $timeamps = true;
}
