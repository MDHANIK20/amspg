<?php $__env->startSection('content'); ?>
<div class="row-fluid">
        <div class="span12">
          <div class="widget-box">
            <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
              <h5>View Rent</h5>
            </div>
            <div class="widget-content nopadding">
                <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="table table-responsive table-striped table-bordered">
                  <tr>
                    <th>SN</th>
                    <th>Name</th>
                    <th>Paid Date</th>
                    <th>Paid Amount</th>
                    <th>Balance</th>
                    <th>Paymode</th>
                    <th>Comment</th>
                    <th>Actions </th>
                  </tr>
                  <?php
                      $i=1;
                  ?>
                  <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if( $rent->cid== $data->id): ?>
                              Rent Received From <strong><?php echo e($data->name); ?></strong>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                      <td><?php echo e($rent->paydate); ?></td>
                      <td><?php echo e($rent->amtpaid); ?></td>
                      <td><?php echo e($rent->balance); ?></td>
                      <td><?php echo e($rent->paymode); ?></td>
                      <td><?php echo e($rent->cmnt); ?></td>
                      
                      <td>
                        <a href="view-rent-receipt/<?php echo e($rent['id']); ?>/edit" class="btn btn-warning">View Receipt</a> &nbsp;
                        <a href="/admin/delete-location/<?php echo e($rent['id']); ?>" class="btn btn-danger">Delete</a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </table>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.commondash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>