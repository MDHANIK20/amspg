<?php $__env->startSection('content'); ?>
<div class="row-fluid">
        <div class="span12">
          <div class="widget-box">
            <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
              <h5>Add Location</h5>
            </div>
            <div class="widget-content nopadding">
               <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <form class="form-horizontal" method="POST" action="<?php echo e(route('manager.AddRoom')); ?>" name="basic_validate" id="basic_validate" ><?php echo csrf_field(); ?>
                <div class="control-group">
                  <label class="control-label">ROOM No</label>
                  <div class="controls">
                    <input type="text" name="rno" required>
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label">Total Seat</label>
                  <div class="controls">
                    <input type="text" name="seats" required>
                  </div>
                </div>
               
                <div class="control-group">
                  <label class="control-label">Building </label>
                  <div class="controls">
                   <select name="bid" id="">
                     <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($building['id']); ?>"><?php echo e($building['name']); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   </select>
                  </div>
                </div>
               
                <div class="form-actions">
                  <input type="submit" value="Add Room" class="btn btn-success">    
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.commondash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>