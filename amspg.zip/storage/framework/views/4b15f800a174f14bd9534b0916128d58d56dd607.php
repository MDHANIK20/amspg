<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'AMS ACCOMMODATION')); ?></title>

 

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
   
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-responsive.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/fullcalendar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/matrix-style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/matrix-media.css')); ?>" />
    <link href=" <?php echo e(asset('/public/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href=" <?php echo e(asset('css/jquery.gritter.css')); ?>" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
    <?php echo $__env->make('layouts.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="content">
            <div id="content-header">
                    <div id="breadcrumb"> 
                      
                    <a href="<?php echo e('dashboard'); ?>">Home <i class="icon-home"></i></a>               
                    <?php $link = "" ?>
                    <?php for($i = 1; $i <= count(Request::segments()); $i++): ?>
                        <?php if($i < count(Request::segments()) & $i > 0): ?>
                        <?php $link .= Request::segment($i); ?>
                        <a href="<?= $link ?>"><?php echo e(ucwords(str_replace('-',' ',Request::segment($i)))); ?></a> 
                        <?php else: ?> <?php echo e(ucwords(str_replace('-',' ',Request::segment($i)))); ?>

                        <?php endif; ?>
                    <?php endfor; ?>
                   
                    </div>
             
         <?php echo $__env->yieldContent('content'); ?>
            </div>
         <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
   
